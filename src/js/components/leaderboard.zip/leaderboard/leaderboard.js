import AjaxModule from '../../modules/ajax';
import './leaderboard.css';

const leaderBoardTemplate = require('./leaderboard.pug');

const root = document.getElementById('root');

const pagesCount = 5;

const leaderboardCallback = (response) => {
  response.json().then((users) => {
    root.innerHTML = leaderBoardTemplate({ 
      users,
      pagesCount,
     });
  });
};

export default function createLeaderboard() {
  const count = 5;
  const start = 0;
  AjaxModule.Get({
    callback: leaderboardCallback,
    path: `/users/${start}/${count}` ,
  });
}
